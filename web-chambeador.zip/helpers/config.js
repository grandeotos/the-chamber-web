var config = {
    host: 'the-chamber-web.ckqbx0wdqtxo.us-east-1.rds.amazonaws.com',
    user: 'TheChamber_Game',
    password: 'n2TyHuJYPPP59SVu',
    database: 'thechamber'
}
module.exports = config;